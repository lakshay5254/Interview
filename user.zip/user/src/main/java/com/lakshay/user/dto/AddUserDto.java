package com.lakshay.user.dto;

import lombok.Data;
@Data
public class AddUserDto {
    private String name;
    private int age;
    private String address;
}
