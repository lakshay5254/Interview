package com.lakshay.user.exception;

public class UserNotFound extends RuntimeException {
    public UserNotFound (String exMessage) {
        super(exMessage);
    }
}

