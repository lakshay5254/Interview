package com.lakshay.user.service;

import com.lakshay.user.dto.AddUserDto;
import com.lakshay.user.exception.UserNotFound;
import com.lakshay.user.model.User;
import com.lakshay.user.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.nio.file.attribute.UserPrincipalNotFoundException;
import java.util.List;

@Service
@AllArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public int addUser(AddUserDto addUserDto) {
        User user = new User();
        user.setName(addUserDto.getName());
        user.setAddress(addUserDto.getAddress());
        user.setAge(addUserDto.getAge());
        return userRepository.save(user).getId();
    }

    public List<User> getUser() {
        return userRepository.findAll();
    }

    public User getUserById(Integer id) {
        return userRepository.findById(id).orElseThrow(()->new UserNotFound("User ID "+id+" not Found"));
    }
}
