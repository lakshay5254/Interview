package com.lakshay.user.controller;

import com.lakshay.user.dto.AddUserDto;
import com.lakshay.user.model.User;
import com.lakshay.user.service.UserService;
import lombok.AllArgsConstructor;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

@RestController
@AllArgsConstructor
public class HomeController {
    private final UserService userService;

    @PostMapping("/users")
    public ResponseEntity<Integer> addUser(@RequestBody AddUserDto addUserDto) {
        return ResponseEntity
                .status(CREATED)
                .body(userService.addUser(addUserDto));
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getUser() {
        return ResponseEntity
                .status(OK)
                .body(userService.getUser());
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Integer id) {
        return ResponseEntity
                .status(OK)
                .body(userService.getUserById(id));
    }

}
